//
//  PhysicsKit_macos.h
//  PhysicsKit-macos
//
//  Created by Adam Eisfeld on 2021-01-04.
//

#import <Foundation/Foundation.h>

//! Project version number for PhysicsKit_macos.
FOUNDATION_EXPORT double PhysicsKit_macosVersionNumber;

//! Project version string for PhysicsKit_macos.
FOUNDATION_EXPORT const unsigned char PhysicsKit_macosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PhysicsKit_macos/PublicHeader.h>


