//
//  PhysicsKit_ios.h
//  PhysicsKit-ios
//
//  Created by Adam Eisfeld on 2021-01-04.
//

#import <Foundation/Foundation.h>

//! Project version number for PhysicsKit_ios.
FOUNDATION_EXPORT double PhysicsKit_iosVersionNumber;

//! Project version string for PhysicsKit_ios.
FOUNDATION_EXPORT const unsigned char PhysicsKit_iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PhysicsKit_ios/PublicHeader.h>


